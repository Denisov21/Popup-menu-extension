# Changelog Pop menu Brackets

## v 1.1.1

* Fix a small problem
* PR 2
* PR 1
* PR 3

## v 2.0.1

* Fix a small problem in Italian language
* PR 4
* PR 5

## v 2.1.2

* Added pt-br strings
* PR 6
* PR 7
* PR 8
