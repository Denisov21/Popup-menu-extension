# Changelog Pop menu Brackets

## v 1.1.1

Fix a small problem
PR 2
PR 1
PR 3
